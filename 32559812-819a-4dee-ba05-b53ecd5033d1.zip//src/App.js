import "./styles.css";

export default function App() {
  const pelicula1 = "EraDeHielo";
  const pelicula2 = "FinDelMundo";
  const pelicula3 = "ToyStory";
  const pelicula4 = "Madagascar";
  const pelicula5 = "Flash";

  return (
    <div className="App">
      <h1>Mis peliculas Favoritas</h1>
      <p>el total de peliculas son: {5}</p>
      <p>Mi pelicula favorita es: {pelicula1} </p>
    </div>
  );
}
